/*
  ble_definitions - Library containing predefined uuids for BLE Services and Characteristics.
  Created by D. Amaxilatis, July 11, 2019.
  Released into the public domain.
*/
#ifndef BLE_CUSTOM_SERVICE_DEFINITIONS_H
#define BLE_CUSTOM_SERVICE_DEFINITIONS_H

//custom BLE SERVICES

#endif